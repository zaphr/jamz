Guitar Tuner
Copyright (c) 2002 Mike Gieson

If you use the guitar tuner on your web site, please provide a link back to me using the following as an example:

Guitar Tuner courtesy of the folks at <a href="http://www.wimpyplayer.com">Wimpy Player</a>

To use the tuner on your site:

1. Open the file named "tuner.html" with a text eidtor.
2. Copy and paste all of the code anywhere between the opening <body> and closing </body> tag in your web page.

Thanks,
-mike
